//***************************************************************************************************************************************
//**
//**  Author: Yash P. Patel 
//**  Date:   January, 22, 2012
//**  Description: ShootEmUp - ShootEmUp is a shooting game where the player has to use the mouse to shoot the UFO's that are trying to
//**                           take over Earth. This is a 1 player game, and whenever the player shoots the UFO, they get 1 point. The  
//**                           player gets about roughly 5 minutes to shoot down many UFO's as possible and get the highest amount of 
//**                           points as possible. There are going to be 6 UFO's flying around the screen in different direction with
//**                           different speeds. So the player has to get down many of them as possible by simply clicking on them. The  
//**                           game will automatically end after 5 minutes are done, and at the end of the game, the final score will be 
//**                           shown and a appreciation for saving our world.
//**                          
//**  Input: - The player uses the mouse to control the game.
//**         - The player has to click on the flying UFO's to get points.   
//****************************************************************************************************************************************

import java.awt.*;
import java.applet.*;
import java.util.Random;
import java.awt.event.*;


public class ShootEmUp extends Applet implements Runnable, MouseListener, MouseMotionListener{
  
   Graphics bufferGraphics;// bufferGraphics for better results, and stop the flickering.
   Image offscreen;
   Dimension dim;
   public final int screenWidth = 806; // Screen Width for boundaries. 
   public final int screenHeight = 496; // Screen Height for boundaries. 
   private Image backGround, alienShip, sniper, audience, startBackground, goodJob; // Images for the UFO's, backgrounds, sniper, etc..
   private AudioClip shootSound; // Play sound when user when clicked on UFO's.
   int alienShipX = 0, alienShip2X = 680, alienShip3X = 0, alienShip4X = 680, alienShip5X = 0, alienShip6X = 680; // Starting X coordinates for the UFO's.
   int alienShipY = 10, alienShip2Y = 50, alienShip3Y = 100, alienShip4Y = 160, alienShip5Y = 210 , alienShip6Y = 260; // Starting Y coordinates for the UFO's.
   int clickX, clickY; // Keep track of the user's click and check for collision.
   int score = 0, counter = 0; // Keep tracks of the user's score, and counter for startscreen.
   int timer = 300, minutes = 5, seconds = 1; // Keep track of the time.
   int startScreen = 0; // 0 = start screen with instruction , 1 = start screen with the game menu, 2 = end screen.
   Font title, instruction, finalText; // Text for the starting, middle and the end startscreen.
   
//***************************************************************************************************************************************
//**   Method: init
//**   This INIT method is used to intialize the host of variables when the program starts. In here the images of th UFO's the background
//**   image, the sound, doublebuffering and mousemotion listener are gathered up and ready to be used further in the program.
//**   
//****************************************************************************************************************************************
   
   
    public void init() {
      
      dim = getSize(); // initializes bufferGraphics.
      offscreen = createImage(dim.width, dim.height);
      bufferGraphics = offscreen.getGraphics ();
      shootSound = this.getAudioClip (this.getDocumentBase(), "sound.wav"); // Sound heard when shot the UFO's.
      startBackground = this.getImage(this.getDocumentBase(), "startBackground.jpg"); // Introductory background image.
      backGround = this.getImage(this.getDocumentBase(), "backGround.jpg"); // Main screen background.
      alienShip = this.getImage(this.getDocumentBase(), "alienShip.gif"); // UFO's Image.
      sniper = this.getImage(this.getDocumentBase(),"sniper.gif");
      audience = this.getImage(this.getDocumentBase(),"audience.gif");
      goodJob = this.getImage(this.getDocumentBase(),"goodJob.gif");      
      title= new Font ("Algerian", Font.BOLD, 36);   // Font for instructions and score at the main screen and the starting screen.
      instruction = new Font ("Rockwell", Font.BOLD, 16);
      finalText = new Font ("Algerian", Font.BOLD, 36);
      addMouseListener (this);
      addMouseMotionListener(this);   
      
    } // End of init method.
    
//********************************************************************************************************************* 
//**  Method: MouseClicked
//**  This MouseClicked method is to get the cordinates where the user has clicked, and also checks if the user has 
//**  clicked on any of the 6 UFO's for collision detection. If use clicked on any of the 6 the user gets a point. 
//**  Also, when this collision happens a sound is played, to make user realize they have earned a point.
//**    
//*********************************************************************************************************************     
    
    public void mouseEntered ( MouseEvent e ) {}
    public void mouseExited( MouseEvent e ) {}
    public void mouseClicked ( MouseEvent e ) {
    
    clickX = e.getX()-30; // X Corodinate of where user clicked.
    clickY = e.getY()-30; // Y Coordinate of where user clicked.
  
      
    if (startScreen == 1) { // Checkes if the collision occured at the main game screen.
      if ((clickX >= alienShipX) && (clickX <= alienShipX+80) && (clickY >= alienShipY) && (clickY <= alienShipY+80)){ // score incremented by 1 and sound played if user click on UFO 1. 
        score++;
        shootSound.play();
      }
      else if ((clickX >= alienShip2X) && (clickX <= alienShip2X+80) && (clickY >= alienShip2Y) && (clickY <= alienShip2Y+80)){// score incremented by 1 and sound played if user click on UFO 2. 
        score++;
        shootSound.play();
      }
      else if ((clickX >= alienShip3X) && (clickX <= alienShip3X+80) && (clickY >= alienShip3Y) && (clickY <= alienShip3Y+80)){// score incremented by 1 and sound played if user click on UFO 3.
        score++;
        shootSound.play();
      }
      else if ((clickX >= alienShip4X) && (clickX <= alienShip4X+80) && (clickY >= alienShip4Y) && (clickY <= alienShip4Y+80)){// score incremented by 1 and sound played if user click on UFO 4.
        score++;
        shootSound.play();
      }
      else if ((clickX >= alienShip5X) && (clickX <= alienShip5X+80) && (clickY >= alienShip5Y) && (clickY <= alienShip5Y+80)){// score incremented by 1 and sound played if user click on UFO 5. 
        score++;
        shootSound.play();
      }
      else if ((clickX >= alienShip6X) && (clickX <= alienShip6X+80) && (clickY >= alienShip6Y) && (clickY <= alienShip6Y+80)){// score incremented by 1 and sound played if user click on UFO 6. 
        score++;
        shootSound.play();
      }
                    
        repaint();
        e.consume();
      }
    }

    public void mousePressed ( MouseEvent e ) {}
//********************************************************************************************************************* 
//**  Method: MouseMoved
//**  This MouseMoved method is used to drag the sniper rifle image for a better gaming experience, therefore 
//**  making it easier for user to shoot the UFOs.
//**    
//*********************************************************************************************************************         
    public void mouseMoved ( MouseEvent e ) {
            
      clickX = e.getX()-30;
      clickY = e.getY()-30;       

          
      repaint();
      e.consume();}
      
    public void mouseDragged ( MouseEvent e ) {}
    public void mouseReleased ( MouseEvent e ) {}
            
    public void start () {
      Thread buuBuu = new Thread (this);
      buuBuu.start();
    }
    
//************************************************************************************************** Paint Method    
    public void paint (Graphics g){
      
      bufferGraphics.clearRect(0,0, dim.width, dim.height);
     
      if (startScreen == 0){
          bufferGraphics.drawImage(startBackground, 0,0, this);
          bufferGraphics.setFont(title);
          bufferGraphics.setColor(Color.red);
          bufferGraphics.drawString("Shoot 'Em Up!", 230,50);
          bufferGraphics.setFont(instruction);
          bufferGraphics.setColor(Color.green);
          bufferGraphics.drawString("The Game objective is to shoot down many UFO's as possible. ",150,130);
          bufferGraphics.drawString("You're hired by the US governent to shoot down many UFO's ",150,160);
          bufferGraphics.drawString("by the sniper gun we provide you. Therefore you have to shoot  ",150,190);
          bufferGraphics.drawString("them down before theytake over Earth. Each UFO you shoot down, ",150,220);
          bufferGraphics.drawString("you will earn 1 point and you have 5 minutes to take down many ",150,250);
          bufferGraphics.drawString("UFO possible and get maximum points. Thereis going to be  ",150,280);      
          bufferGraphics.drawString("audience to cheer you up. So Good Luck and SAVE OUR EARTH ",150,310); 
          bufferGraphics.drawString("FROM THESE DANGEROUS UFO'S!!!!!! ",150,340);
          bufferGraphics.setColor(Color.blue);
          bufferGraphics.drawString("HOPE YOU ENJOY THE GAME! ",240,400);      
          bufferGraphics.setColor(Color.orange);
          bufferGraphics.drawString("The game will be automatically redirected. ",180,450);      
      }
      
      
      
     else if (startScreen == 1){
          bufferGraphics.drawImage(backGround,0,0,this);
          bufferGraphics.drawImage(alienShip,alienShipX, alienShipY,this);
          bufferGraphics.drawImage(alienShip,alienShip2X, alienShip2Y,this);     
          bufferGraphics.drawImage(alienShip,alienShip3X, alienShip3Y,this);
          bufferGraphics.drawImage(alienShip,alienShip4X, alienShip4Y,this);
          bufferGraphics.drawImage(alienShip,alienShip5X, alienShip5Y,this);
          bufferGraphics.drawImage(alienShip,alienShip6X, alienShip6Y,this);      
          bufferGraphics.drawImage(sniper,clickX, clickY,this);   
          bufferGraphics.drawImage(audience,0,310,this);
          bufferGraphics.drawImage(audience,372,310,this);   
          bufferGraphics.setColor(Color.green);
          bufferGraphics.drawString("Timer:" + minutes + ":" + seconds, 650,20);
          bufferGraphics.setColor(Color.red);
          bufferGraphics.drawString("Score:" + score, 20, 20);
        
     }
        
     else if (startScreen == 2){
          bufferGraphics.drawImage(startBackground,0,0,this);
          bufferGraphics.drawImage(goodJob,130,30,this);        
          bufferGraphics.setFont(finalText);
          bufferGraphics.setColor(Color.blue);
          bufferGraphics.drawString("Your Final Score Is:" + score, 130, 250);
          bufferGraphics.setColor(Color.red); 
          bufferGraphics.drawString("Thanks for saving our world. " , 50, 400);
     }
       
    
    g.drawImage(offscreen,0,0,this);

      
    } // End of paint method.
    
    public void update(Graphics g)
       { paint(g); }
//****************************************************************************************************** Run Method
    public void run() {

      while (timer > 0){
        
      if (startScreen == 0)
          counter++;
        if (counter >= 100)
          startScreen = 1;
 
        
      if (startScreen == 1){  
        timer--;
        seconds = seconds - 1;
      if (seconds == 0) {
         minutes = minutes - 1;
         seconds = 60;}

     alienShipX = alienShipX + 30;
         if (alienShipX >= 680)
            alienShipX=0;
     alienShip2X = alienShip2X - 35;
         if (alienShip2X <= 0)
            alienShip2X=680;    
     alienShip3X = alienShip3X + 50;
         if (alienShip3X >= 680)
            alienShip3X=0;    
     alienShip4X = alienShip4X - 28;
         if (alienShip4X <= 0)
            alienShip4X=680;
     alienShip5X = alienShip5X + 38;
         if (alienShip5X >= 680)
            alienShip5X=0;
     alienShip6X = alienShip6X - 40;
         if (alienShip6X <= 0)
           alienShip6X=680;
      }// startscreen 1.

      repaint(); 
      try { Thread.sleep(125);  }
      catch(InterruptedException e){}

        
      }// End of While. 
       
      startScreen = 2;
        repaint(); 
    }// End of Run.
}
    

       